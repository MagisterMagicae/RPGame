import { MenuScreen } from '@/components/MenuScreen';
import { StyleSheet } from 'react-native';

export default function HomeScreen() {
  return <MenuScreen />;
}

const styles = StyleSheet.create({});
